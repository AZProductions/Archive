# SecureVast
The Free Open-Source Password Creator

## [What's next for SecureVast?]( https://link.medium.com/4XA1xVnIKjb)

![image](https://user-images.githubusercontent.com/66299945/117479224-599b4000-af60-11eb-9e4d-d0265c4ea079.png)

## Installation

[Download the file in Github.](https://github.com/AZProductions/SecureVast/releases/tag/ver1)

## License
[GPL 3.0](https://choosealicense.com/licenses/gpl-3.0/)
