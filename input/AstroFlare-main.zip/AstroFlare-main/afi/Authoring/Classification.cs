namespace AstroFlare.CodeAnalysis.Authoring
{
    public enum Classification
    {
        Text,
        Keyword,
        Identifier,
        Number,
        String,
        Comment
    }
}
