namespace AstroFlare
{
    internal static class Program
    {
        private static void Main()
        {
            var repl = new AstroFlareRepl();
            repl.Run();
        }
    }
}
