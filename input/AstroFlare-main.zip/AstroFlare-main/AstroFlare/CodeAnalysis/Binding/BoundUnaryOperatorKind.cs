namespace AstroFlare.CodeAnalysis.Binding
{
    internal enum BoundUnaryOperatorKind
    {
        Identity,
        Negation,
        LogicalNegation,
        OnesComplement
    }
}
