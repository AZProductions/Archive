namespace AstroFlare.UI.Theme
{
    class Theme
    {
        private static ThemeKind _current;
        public Theme(ThemeKind kind)
        {
            _current = kind;
        }
    }
}