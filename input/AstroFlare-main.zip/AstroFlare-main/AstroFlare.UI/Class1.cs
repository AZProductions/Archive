﻿using System;

namespace AstroFlare.UI
{
    public class Class1
    {

    }
}
