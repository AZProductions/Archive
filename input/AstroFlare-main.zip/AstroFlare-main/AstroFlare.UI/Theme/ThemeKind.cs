namespace AstroFlare.UI.Theme
{
    public enum ThemeKind
    {
        Dark,
        Light,
        Violet
    }
}