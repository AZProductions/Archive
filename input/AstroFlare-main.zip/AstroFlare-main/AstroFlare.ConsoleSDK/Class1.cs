﻿using System;

namespace AstroFlare.ConsoleSDK
{
    public class Class1
    {
    }
}
