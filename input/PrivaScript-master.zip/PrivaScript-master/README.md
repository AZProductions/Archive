# PrivaScript
Free - Fast - WebBrowser
