# About the icon.
The icon we use as our logo is a modified version of a [fluent icon](https://icons8.com/icon/Ike9AXWbZ5jm/share-rounded) provided by [Icons8](https://icons8.com)
---
![Image](final.png)