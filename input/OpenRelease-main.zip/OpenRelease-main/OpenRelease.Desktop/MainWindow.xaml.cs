﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ModernWpf;
using OpenRelease.Desktop.Libs;
using OpenRelease.Desktop;
using Microsoft.Win32;
using LiveCharts;
using LiveCharts.Wpf;
using System.Reflection;
using ModernWpf.Controls;
using System.Net;
using System.IO;

namespace OpenRelease.Desktop
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            if (Properties.Settings.Default.DarkTheme == true)
                ThemeManager.SetRequestedTheme(window, ElementTheme.Dark);
            else
                ThemeManager.SetRequestedTheme(window, ElementTheme.Light);
            Libs.WindowColors.BGColor =  ModernWpf.ThemeManager.GetRequestedTheme(window).ToString();
            if (Properties.Settings.Default.CenterScreen == true)
            {
                RCenter.IsChecked = true;
                window.WindowStartupLocation = WindowStartupLocation.CenterScreen;
            }
            else 
            {
                RRecent.IsChecked = true;
                this.Top = Properties.Settings.Default.Top;
                this.Left = Properties.Settings.Default.Left;
                this.Height = Properties.Settings.Default.Height;
                this.Width = Properties.Settings.Default.Width;
            }
            if (Libs.WindowColors.BGColor == "Black" || Libs.WindowColors.BGColor == "Dark")
            { RDark.IsChecked = true; }
            else { RLight.IsChecked = true; }
                ColorLib colorLib = new ColorLib();
            this.DataContext = colorLib;
            RLabel.Visibility = Visibility.Hidden;
            VLabel.Content = "V" + Assembly.GetExecutingAssembly().GetName().Version.ToString();
            /*DashChart.DisableAnimations = true;
            LineSeries s = new LineSeries();
            var test1 = new ChartValues<double>();
            test1.Add(2.4);
            test1.Add(23);
            s.Values = test1;
            s.Title = "test";
            DashChart.Series.Add(s);
            DashChart.Update();*/
        }

        public static class ProjectLib 
        {
            public static void AddFile(string loc) 
            {
                Properties.Settings.Default.SavedProjects.Add(@loc);
                Properties.Settings.Default.Save();
            }

            public static void GetFiles() 
            {
                foreach (string line in Properties.Settings.Default.SavedProjects.Cast<string>().ToArray()) 
                {
                    MainWindow mv = new MainWindow();
                    mv.TabView.Items.Add(line);
                    MessageBox.Show(line);
                }
            }
        }

        public class ColorLib
        {
            public Brush ThemeAwareBackground
            {
                get 
                {
                    var bc = new BrushConverter();
                    return (Brush)bc.ConvertFromString(GetThemeAwareHex());
                }
            }
            string GetThemeAwareHex() 
            {
                if (Libs.WindowColors.BGColor == "Black" || Libs.WindowColors.BGColor == "Dark")
                {
                    return "#333333";
                }
                else { return "#E6E6E6"; }
            }
            public SolidColorBrush ThemeAwareText
            {
                get
                {

                    if (Libs.WindowColors.BGColor == "Black" || Libs.WindowColors.BGColor == "Dark")
                    {
                        return new SolidColorBrush(Colors.White);
                    }
                    else { return new SolidColorBrush(Colors.Black); }
                }
            }
            public Brush AcrilycBrush
            {
                get
                {
                    var bc = new BrushConverter();
                    return (Brush)bc.ConvertFromString(GetAcrilycHex());
                }
            }
            string GetAcrilycHex()
            {
                if (Libs.WindowColors.BGColor == "Black" || Libs.WindowColors.BGColor == "Dark")
                {
                    return "#19FFFFFF";
                }
                else { return "#19000000"; }
            }
        }

        private void window_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.D && (Keyboard.Modifiers & ModifierKeys.Control) == ModifierKeys.Control)
            {
                TabView.SelectedItem = DashView;
            }
            
            if (e.Key == Key.O && (Keyboard.Modifiers & ModifierKeys.Control) == ModifierKeys.Control)
            {
                TabView.SelectedItem = ProjectView;
            }
        }

        private void CProject_Click(object sender, RoutedEventArgs e)
        {
            ContentDialog c = new ContentDialog();
            c.Title = "Create new project";
            c.ShowAsync();
        }

        private void OProject_Click(object sender, RoutedEventArgs e)
        {
            string loc = "";
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.DefaultExt = ".OpenR";
            openFileDialog.Filter = "OpenRelease Files (*.OpenR)|*.OpenR|All files (*.*)|*.*";
            if (openFileDialog.ShowDialog() == true)
                loc = openFileDialog.FileName;
            MessageBox.Show(loc);
            ProjectFileSerializer pfd = new ProjectFileSerializer(loc);
        }

        private void RDefault_Checked(object sender, RoutedEventArgs e)
        {
            ThemeManager.SetRequestedTheme(window, ElementTheme.Default);
        }

        private void RDark_Checked(object sender, RoutedEventArgs e)
        {
            ThemeManager.SetRequestedTheme(window, ElementTheme.Dark);
            Properties.Settings.Default.DarkTheme = true;
            Properties.Settings.Default.Save();
            RLabel.Visibility = Visibility.Visible;

        }

        private void RLight_Checked(object sender, RoutedEventArgs e)
        {
            ThemeManager.SetRequestedTheme(window, ElementTheme.Light);
            Properties.Settings.Default.DarkTheme = false;
            Properties.Settings.Default.Save();
            RLabel.Visibility = Visibility.Visible;
        }

        private void window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            Properties.Settings.Default.Top = this.Top;
            Properties.Settings.Default.Left = this.Left;
            Properties.Settings.Default.Height = this.Height;
            Properties.Settings.Default.Width = this.Width;
            Properties.Settings.Default.Save();
        }

        private void RCenter_Checked(object sender, RoutedEventArgs e)
        {
            Properties.Settings.Default.CenterScreen = true;
            Properties.Settings.Default.Save();
        }

        private void RRecent_Checked(object sender, RoutedEventArgs e)
        {
            Properties.Settings.Default.CenterScreen = false;
            Properties.Settings.Default.Save();
        }

        private void MISettings_Click(object sender, RoutedEventArgs e)
        {
            TabView.SelectedItem = SettingsView;
        }

        private void BTNConfirm_Click(object sender, RoutedEventArgs e)
        {
            Flyout f = flyout;
            if (f != null)
            {
                f.Hide();
                var client = new WebClient();
                var uri = new Uri(API.GetDownloadAPI.URL.url);

                client.DownloadProgressChanged += new DownloadProgressChangedEventHandler(client_DownloadProgressChanged);
                client.DownloadFileCompleted += (sender, e) => MessageBox.Show("Finished");
                client.DownloadFileAsync(uri, @"D:\Github\OpenRelease\test.png");
            }
        }

        void client_DownloadProgressChanged(object sender, DownloadProgressChangedEventArgs e)
        {
            double bytesIn = double.Parse(e.BytesReceived.ToString());
            double totalBytes = double.Parse(e.TotalBytesToReceive.ToString());
            double percentage = bytesIn / totalBytes * 100;
            PBUpdate.Value = int.Parse(Math.Truncate(percentage).ToString());
        }

        private void BTNCheckForUpdates_Click(object sender, RoutedEventArgs e)
        {
            string html = string.Empty;
            string url = @"https://azproductions.github.io/OpenRelease/api.json";
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            request.AutomaticDecompression = DecompressionMethods.GZip;
            using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
            using (Stream stream = response.GetResponseStream())
            using (StreamReader reader = new StreamReader(stream))
            {
                html = reader.ReadToEnd();
            }
            var requests = API.GetDownloadAPI.GetRequest.FromJson(html);
            foreach (API.GetDownloadAPI.GetRequest value in requests)
            {
                var version1 = new Version(Assembly.GetExecutingAssembly().GetName().Version.ToString());
                var version2 = new Version(value.Version);

                var result = version1.CompareTo(version2);
                if (result > 0)
                { } //Ignore, the version on the server is older than the running version.
                else if (result < 0) 
                {
                    BTNUpdate.IsEnabled = true;
                    API.GetDownloadAPI.URL.url = value.Url.AbsoluteUri;
                }    
            }
        }
    }
}
