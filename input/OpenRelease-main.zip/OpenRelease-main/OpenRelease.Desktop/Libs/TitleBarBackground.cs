﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Media;

namespace OpenRelease.Desktop.Libs
{
    public static class TitleBarBackground
    {
        public static Color GetColor() 
        {
            var bc = new BrushConverter();
            if (Libs.WindowColors.BGColor == "Black" || Libs.WindowColors.BGColor == "Dark")
            {
                return (Color)ColorConverter.ConvertFromString("#1E1E1E");
            }
            else { return (Color)ColorConverter.ConvertFromString("#E6E6E6"); }
        }
    }
}
