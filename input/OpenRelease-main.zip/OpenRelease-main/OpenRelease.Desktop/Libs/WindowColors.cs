﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Media;

namespace OpenRelease.Desktop.Libs
{
    public static class WindowColors
    {
        public static string BGColor { get; set; }
    }
}
