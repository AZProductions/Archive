﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace OpenRelease.Desktop.Libs
{
    public class ProjectFileSerializer
    {
        public readonly string Location;
        public readonly string Project;
        public readonly string Status;
        public readonly string NewVer;
        public readonly string[] Releases;
        public ProjectFileSerializer(string location)
        {
            if (File.Exists(location))
            {
                Location = location;
                string[] vs = File.ReadAllLines(Location);
                foreach (string Lines in vs)
                {
                    if (Lines.StartsWith("#")) { } //Comment.
                    else if (Lines.StartsWith("%")) 
                    {
                        if (Lines.StartsWith("PROJECT=")) 
                        {
                            string temp = Lines.Replace("%PROJECT=", "");
                            Project = temp.TrimStart('"').TrimEnd('"');
                        }
                        else if (Lines.StartsWith("STATUS="))
                        {
                            string temp = Lines.Replace("%STATUS=", "");
                            Status = temp.TrimStart('"').TrimEnd('"');
                        }
                    }
                }
            }
        }
    }
}
