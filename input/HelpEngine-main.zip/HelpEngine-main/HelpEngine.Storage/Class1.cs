﻿using System;

namespace HelpEngine.Storage
{
    public class Class1
    {
    }
}
