﻿using System;

namespace HelpEngine.Logic
{
    public class Class1
    {
    }
}
