﻿using System;
using Spectre.Console;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using Cocona;
using SDK = Kookaburra.SDK; //Rename Kookaburra.SDK to SDK. To remove confusion between libraries.
using KKB;

namespace KKB
{
    class Program
    {
        static void Main(string[] args)
        {
            CoconaApp.Run<Program>(args);
        }

        [Command("run")]
        public void RunSearch(string path = "") 
        {
            string[] files = Directory.GetFiles(Directory.GetCurrentDirectory().ToString(), "*.kookaburra");
            if (files.Length < 1) 
            {
                Console.WriteLine("Please specifify the path, or have a .Kookaburra file in the running directory.");
            }
            else
            {
                Run(files[0]);
            }
        }

        [Ignore]
        public void Run(string path)
        {
            if (!string.IsNullOrEmpty(path))
            {
                FileInfo file = new FileInfo(path);
                int line = 1;
                Console.ForegroundColor = ConsoleColor.White;
                var Intname = new[] { "" };
                List<string> Stringname = new List<string>();
                List<string> Stringvalue = new List<string>();
                BarChart bc = new BarChart();
                Table tb = new Table();
                bool GridSelect = false;
                string debugoff = File.ReadLines(file.ToString()).First();
                if (debugoff == "app.debug-off") { } else { Debuger(); }
                Isettingsconf.Quietmode = true;
                if (file.Extension == ".kookaburra")
                {
                    Console.Title = "(" + file + ") Kookaburra Shell";
                    if (file.Exists)
                    {
                        try
                        {
                            string[] readText = File.ReadAllLines(file.ToString());
                            foreach (string s in readText)
                            {
                                if (s.StartsWith("start"))
                                {
                                    string loc = s.Replace("start ", "");
                                    //Console.WriteLine(loc);
                                    ProcessStartInfo startInfo = new ProcessStartInfo();
                                    startInfo.FileName = Format(loc);
                                    startInfo.Arguments = "";
                                    Process.Start(startInfo);
                                }
                                else if (s.StartsWith("exit")) { Environment.Exit(0); script_var.Ifcount = 1; }
                                else if (s.StartsWith("wait")) { Wait(s); script_var.Ifcount = 1; }
                                else if (s.StartsWith("app.title = "))
                                {
                                    Apptitle(s);
                                    script_var.Ifcount = 1;
                                }
                                else if (s == "app.clear")
                                {
                                    Appclear();
                                    script_var.Ifcount = 1;
                                }
                                else if (s.StartsWith("app.size = "))
                                {
                                    Appsize(s);
                                    script_var.Ifcount = 1;
                                }
                                else if (s.StartsWith("import "))
                                {
                                    string name = s.Replace("import ", "");
                                    if (name == "FileIO") { Packages.FileIO = true; }
                                    else if (name == "Net") { Packages.Net = true; }
                                    else { throw new ArgumentException("Synax error at line '" + line + "'." + " C3211"); }
                                }
                                else if (s.StartsWith("print"))
                                {
                                    Print(s);
                                    script_var.Ifcount = 1;
                                }
                                else if (s.StartsWith("new filewriter(") && s.EndsWith(")"))
                                {
                                    if (Packages.FileIO)
                                    {
                                        script_var.Ifcount = 1;
                                        string res1 = s.Replace("new filewriter", "");
                                        string res2 = res1.TrimStart('(');
                                        string res3 = res2.TrimEnd(')');
                                        List<string> Result = new List<string>();
                                        try
                                        {
                                            string res4 = res3.Replace(", ", "/n");
                                            string[] valuearray = res4.Split("/n");
                                            if (valuearray[0].StartsWith('"') && valuearray[0].EndsWith('"'))
                                            {
                                                //loc
                                                string loc1 = valuearray[0].TrimStart('"');
                                                string loc2 = loc1.TrimEnd('"');
                                                Result.Add(loc2);
                                            }
                                            else
                                            {
                                                int num = 0;
                                                int num2 = 0;
                                                foreach (string lines in Stringname)
                                                {
                                                    num++;
                                                    if (lines == valuearray[0])
                                                    {
                                                        foreach (string lines2 in Stringvalue)
                                                        {
                                                            num2++;
                                                            //Console.WriteLine("num=" + num + " num2=" + num2);
                                                            if (num == num2) { Result.Add(lines2); }
                                                        }
                                                        //Console.WriteLine("match");
                                                    }
                                                }
                                            }

                                            if (valuearray[1].StartsWith('"') && valuearray[1].EndsWith('"'))
                                            {
                                                //value
                                                string loc1 = valuearray[1].TrimStart('"');
                                                string loc2 = loc1.TrimEnd('"');
                                                Result.Add(loc2);
                                            }
                                            else
                                            {
                                                int num = 0;
                                                int num2 = 0;
                                                foreach (string lines in Stringname)
                                                {
                                                    num++;
                                                    if (lines == valuearray[1])
                                                    {
                                                        foreach (string lines2 in Stringvalue)
                                                        {
                                                            num2++;
                                                            //Console.WriteLine("num=" + num + " num2=" + num2);
                                                            if (num == num2) { Result.Add(lines2); }
                                                        }
                                                        //Console.WriteLine("match");
                                                    }
                                                }
                                            }

                                            Filewriter(Result[0], Result[1]);

                                            void Filewriter(string path, string value)
                                            {
                                                if (!File.Exists(path))
                                                {
                                                    // Create a file to write to.
                                                    using (StreamWriter sw = File.CreateText(path))
                                                    {
                                                        sw.WriteLine(value);
                                                    }
                                                }
                                                else { File.AppendAllText(path, Environment.NewLine + value); }
                                            }
                                        }
                                        catch { throw new ArgumentException("Synax error at line '" + line + "'." + " C1793"); }

                                    }
                                    else { throw new ArgumentException("Synax error at line '" + line + "'." + " C3965"); }
                                }
                                else if (s.StartsWith("new filereader(") && s.EndsWith("]") && s.Contains(")["))
                                {
                                    if (Packages.FileIO)
                                    {
                                        script_var.Ifcount = 1;
                                        string res1 = s.Replace("new filereader", "");
                                        string res2 = res1.TrimStart('(');
                                        string res3 = res2.TrimEnd(']');
                                        string[] valuearray = res3.Split(")[");

                                        string loc = "";
                                        if (valuearray[0].StartsWith('"') && valuearray[1].EndsWith('"'))
                                        {
                                            string loc1 = valuearray[0].TrimStart('"');
                                            string loc2 = loc1.TrimEnd('"');
                                            loc = loc2;
                                        }
                                        else
                                        {
                                            int num = 0;
                                            int num2 = 0;
                                            foreach (string lines in Stringname)
                                            {
                                                num++;
                                                if (lines == valuearray[0])
                                                {
                                                    foreach (string lines2 in Stringvalue)
                                                    {
                                                        num2++;
                                                        //Console.WriteLine("num=" + num + " num2=" + num2);
                                                        if (num == num2) { loc = lines2; }
                                                    }
                                                    //Console.WriteLine("match");
                                                }
                                            }
                                        }

                                        string counter = "";
                                        if (valuearray[1].StartsWith('"') && valuearray[1].EndsWith('"'))
                                        {
                                            string loc1 = valuearray[1].TrimStart('"');
                                            string loc2 = loc1.TrimEnd('"');
                                            counter = loc2;
                                        }
                                        else
                                        {
                                            int num = 0;
                                            int num2 = 0;
                                            foreach (string lines in Stringname)
                                            {
                                                num++;
                                                if (lines == valuearray[1])
                                                {
                                                    foreach (string lines2 in Stringvalue)
                                                    {
                                                        num2++;
                                                        //Console.WriteLine("num=" + num + " num2=" + num2);
                                                        if (num == num2) { counter = lines2; }
                                                    }
                                                    //Console.WriteLine("match");
                                                }
                                            }
                                        }

                                        int eachcount2 = Int32.Parse(counter);
                                        int eachcounter = 0;
                                        foreach (string lines in File.ReadLines(loc))
                                        {
                                            eachcounter++;
                                            if (eachcounter == eachcount2)
                                            {
                                                Console.WriteLine(lines);
                                            }
                                        }

                                        /*int test = 0;
                                        foreach (string lines in valuearray) 
                                        {
                                            test++;
                                            Console.WriteLine(lines + " |" + test + "|");
                                        }*/
                                    }
                                    else { throw new ArgumentException("Synax error at line '" + line + "'." + " C3965"); }
                                }
                                else if (s.StartsWith("app.color = "))
                                {
                                    Appcolor(s);
                                    script_var.Ifcount = 1;
                                }
                                else if (s.StartsWith("app.background = "))
                                {
                                    string color = s.Replace("app.background = ", "");
                                    color = char.ToUpper(color[0]) + color.Substring(1);
                                    Console.BackgroundColor = (ConsoleColor)Enum.Parse(typeof(ConsoleColor), color);
                                    script_var.Ifcount = 1;
                                }
                                else if (s == "sound.beep()")
                                {
                                    Console.Beep();
                                }
                                else if (s.StartsWith("new image(") && s.EndsWith(")"))
                                {
                                    string result = s.Replace("new image(", "").TrimEnd(')');
                                    string[] result2 = result.Split(", ");
                                    var image = new CanvasImage(Format(result2[0]));
                                    image.MaxWidth(int.Parse(Format(result2[1])));
                                    AnsiConsole.Render(image);
                                }
                                else if (s.StartsWith("sound.play = "))
                                {
                                    string res = s.Replace("sound.play = ", "");
                                    if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                                        Process.Start(@"powershell", $@"-c (New-Object Media.SoundPlayer '{Format(res)}').PlaySync();");
                                    else if (RuntimeInformation.IsOSPlatform(OSPlatform.Linux))
                                    {
                                        try
                                        {
                                            string program = "cvlc";
                                            var pi = new ProcessStartInfo(res)
                                            {
                                                Arguments = Path.GetFileName(res) + " --play-and-exit",
                                                UseShellExecute = true,
                                                WorkingDirectory = Format(res),
                                                FileName = program,
                                                Verb = "OPEN",
                                                WindowStyle = ProcessWindowStyle.Hidden
                                            }; Process p = new Process(); p.StartInfo = pi; p.Start(); p.WaitForExit();
                                        }
                                        catch { Console.WriteLine("Please install VLC Media Player to work."); }
                                    }
                                }
                                else if (s.StartsWith("app.debug-off"))
                                {
                                    //script_var.Ifcount = 1;
                                }
                                else if (s.StartsWith("app.foreground"))
                                {
                                    string color = s.Replace("app.foreground = ", "");
                                    color = char.ToUpper(color[0]) + color.Substring(1);
                                    Console.ForegroundColor = (ConsoleColor)Enum.Parse(typeof(ConsoleColor), color);
                                    script_var.Ifcount = 1;
                                }
                                else if (s.StartsWith("cp "))
                                {
                                    string result = s.Replace("cp ", "");
                                    string[] valuearray = result.Split(", ");
                                    File.Copy(Format(valuearray[0]), Format(valuearray[1]), true);
                                    script_var.Ifcount = 1;
                                }
                                else if (s.StartsWith("mv "))
                                {
                                    string result = s.Replace("cp ", "");
                                    string[] valuearray = result.Split(", ");
                                    File.Move(Format(valuearray[0]), Format(valuearray[1]), true);
                                    script_var.Ifcount = 1;
                                }
                                else if (s.StartsWith("rm "))
                                {
                                    string result = s.Replace("rm ", "");
                                    File.Delete(Format(result));
                                    script_var.Ifcount = 1;
                                }
                                else if (s.StartsWith("Grid.AddColumn("))
                                {
                                    if (GridSelect)
                                    {
                                        string result1 = s.Replace("Grid.AddColumn", "");
                                        string result2 = result1.Replace(")", "");
                                        result2 = result2.Replace("(", "");
                                        tb.AddColumn("[" + Console.ForegroundColor + "]" + Format(result2) + "[/]");
                                    }
                                }
                                else if (s.StartsWith("Grid.AddRow("))
                                {
                                    if (GridSelect)
                                    {
                                        string result1 = s.Replace("Grid.AddRow", "");
                                        string result2 = result1.Replace(")", "");
                                        result2 = result2.Replace("(", "");
                                        string[] valuearray = result2.Split(", ");
                                        tb.AddRow("[" + Console.ForegroundColor + "]" + Format(valuearray[0]) + "[/]", "[" + Console.ForegroundColor + "]" + Format(valuearray[1]) + "[/]");
                                    }
                                }
                                else if (s.StartsWith("Grid.Display("))
                                {
                                    if (GridSelect)
                                        AnsiConsole.Render(tb);
                                }
                                else if (s == "app.breakpoint()")
                                {
                                    var table = new Table();
                                    table.Border = TableBorder.Rounded;
                                    table.AddColumn("[white]Breakpoint[/]");
                                    table.AddRow("[white]Status=[/][green]running[/]");

                                    table.AddRow("[white]-- Strings --[/]");

                                    foreach (string Finalvalue in Stringname)
                                    {
                                        table.AddRow("[blue]" + Finalvalue + "[/]=[red]" + Format(Finalvalue) + "[/]");
                                    }
                                    AnsiConsole.Render(table);
                                }
                                else if (s.StartsWith("new Grid("))
                                {
                                    GridSelect = true;
                                }
                                else if (s.StartsWith("new Barchart"))
                                {
                                    string result1 = s.Replace("new Barchart", "");
                                    string result2 = result1.Replace(")", "");
                                    result2 = result2.Replace("(", "");

                                    bc.Width = 100;
                                    bc.Label("[" + Console.ForegroundColor + "]" + Format(result2) + "[/]");
                                    bc.CenterLabel();
                                    script_var.Ifcount = 1;
                                }
                                else if (s.StartsWith("new Rule("))
                                {
                                    string result = s.Replace("new Rule(", "");
                                    result = result.Replace(")", "");
                                    if (string.IsNullOrWhiteSpace(result))
                                    {
                                        var rule = new Rule("[" + Console.ForegroundColor + "][/]");
                                        AnsiConsole.Render(rule);
                                    }
                                    else
                                    {
                                        var rule = new Rule("[" + Console.ForegroundColor + "]" + Format(result) + "[/]");
                                        AnsiConsole.Render(rule);
                                    }
                                    script_var.Ifcount = 1;
                                }
                                else if (s.StartsWith("new Calendar("))
                                {
                                    string result = s.Replace("new Calendar(", "");
                                    result = result.Replace(")", "");
                                    string[] valuearray = result.Split(", ");
                                    var calendar = new Calendar(int.Parse(valuearray[0]), int.Parse(valuearray[1]));
                                    calendar.HeaderStyle(Style.Parse(Console.ForegroundColor.ToString()));
                                    AnsiConsole.Render(calendar);

                                }
                                else if (s.StartsWith("Barchart.Add(") && s.EndsWith(")"))
                                {
                                    string result = s.Replace("Barchart.Add(", "");
                                    result = result.Replace(")", "");
                                    string[] valuearray = result.Split(", ");
                                    bc.AddItem("[" + Console.ForegroundColor + "]" + Format(valuearray[0]) + "[/]" /*+ Format(valuearray[0])*/, Double.Parse(valuearray[1]), Console.ForegroundColor);
                                    script_var.Ifcount = 1;
                                }
                                else if (s.StartsWith("Barchart.Display(") && s.EndsWith(")"))
                                {
                                    AnsiConsole.Render(bc);
                                }
                                else if (s.StartsWith("zip "))
                                {
                                    if (Packages.FileIO)
                                    {
                                        string result = s.Replace("zip ", "");
                                        string[] valuearray = result.Split(", ");
                                        ZipFile.CreateFromDirectory(Format(valuearray[0]), Format(valuearray[1]));
                                        script_var.Ifcount = 1;
                                    }
                                    else { throw new ArgumentException("Synax error at line '" + line + "'." + " C3965"); }
                                }
                                else if (s.StartsWith("unzip "))
                                {
                                    if (Packages.FileIO)
                                    {
                                        string result = s.Replace("unzip ", "");
                                        string[] valuearray = result.Split(", ");
                                        ZipFile.ExtractToDirectory(Format(valuearray[0]), Format(valuearray[1]));
                                        script_var.Ifcount = 1;
                                    }
                                    else { throw new ArgumentException("Synax error at line '" + line + "'." + " C3965"); }
                                }
                                else if (s.StartsWith("if") && s.EndsWith(":"))
                                {
                                    string result = s.Replace(":", "");
                                    Newif(result);
                                }
                                else if (s.StartsWith("else") && s.EndsWith(":"))
                                {
                                    Else();
                                }
                                else if (s.StartsWith(" "))
                                {
                                    string input = s.Replace("  ", "");
                                    //Console.WriteLine(input + "/" + script_var.Ifcount);
                                    if (input.StartsWith("print"))
                                    {
                                        if (script_var.Ifcount == 2)
                                        {
                                            Print(input);
                                        }
                                    }
                                    else if (input.StartsWith("wait"))
                                    {
                                        if (script_var.Ifcount == 2)
                                        {
                                            Wait(input);
                                        }
                                    }
                                    else if (input.StartsWith("set "))
                                    {
                                        if (script_var.Ifcount == 2)
                                        {
                                            Set(input);
                                        }
                                    }
                                    else if (input.StartsWith("exit"))
                                    {
                                        if (script_var.Ifcount == 2)
                                        {
                                            Environment.Exit(0);
                                        }
                                    }
                                    else if (input.StartsWith("app.title = "))
                                    {
                                        if (script_var.Ifcount == 2)
                                        {
                                            Apptitle(input);
                                        }
                                    }
                                    else if (input.StartsWith("app.color = "))
                                    {
                                        if (script_var.Ifcount == 2)
                                        {
                                            Appcolor(input);
                                        }
                                    }
                                    else if (input.StartsWith("app.size = "))
                                    {
                                        if (script_var.Ifcount == 2)
                                        {
                                            Appsize(input);
                                        }
                                    }
                                    else if (input.StartsWith("start"))
                                    {
                                        if (script_var.Ifcount == 2)
                                        {
                                            string loc = input.Replace("start ", "");
                                            //Console.WriteLine(loc);
                                            ProcessStartInfo startInfo = new ProcessStartInfo();
                                            startInfo.FileName = loc;
                                            startInfo.Arguments = "";
                                            Process.Start(startInfo);
                                        }
                                    }
                                    else
                                    {
                                        throw new ArgumentException("7 Internal error at line '" + line + "'");
                                    }
                                }
                                else if (s.StartsWith("int "))
                                {
                                    Int(s);
                                    script_var.Ifcount = 1;
                                }
                                else if (s.StartsWith("new Alert(") && s.EndsWith(")"))
                                {
                                    string result = s.Replace("new Alert(", "").TrimEnd(')');
                                    string[] Valuearray = result.Split(", ");
                                    Kookaburra.SDK.Alert.Display(Format(Valuearray[0]) + Environment.NewLine, int.Parse(Valuearray[1]), true);
                                }
                                else if (s.StartsWith("figlet "))
                                {
                                    string result = s.Replace("figlet ", "");
                                    AnsiConsole.Render(
                                    new FigletText(Format(result))
                                        .LeftAligned()
                                        .Color(Console.ForegroundColor));
                                    script_var.Ifcount = 1;
                                }
                                else if (s.StartsWith("figlet.center"))
                                {
                                    string result = s.Replace("figlet.center ", "");
                                    AnsiConsole.Render(
                                    new FigletText(Format(result))
                                        .Centered()
                                        .Color(Console.ForegroundColor));
                                    script_var.Ifcount = 1;
                                }
                                else if (s.StartsWith("figlet.right"))
                                {
                                    string result = s.Replace("figlet.right ", "");
                                    AnsiConsole.Render(
                                    new FigletText(Format(result))
                                        .RightAligned()
                                        .Color(Console.ForegroundColor));
                                    script_var.Ifcount = 1;
                                }
                                else if (s.StartsWith("figlet.left"))
                                {
                                    string result = s.Replace("figlet.left ", "");
                                    AnsiConsole.Render(
                                    new FigletText(Format(result))
                                        .LeftAligned()
                                        .Color(Console.ForegroundColor));
                                    script_var.Ifcount = 1;
                                }
                                else if (s.StartsWith("p.center"))
                                {
                                    string result = s.Replace("p.center ", string.Empty);
                                    string Value = Format(result);
                                    Console.SetCursorPosition((Console.WindowWidth - Value.Length) / 2, Console.CursorTop);
                                    Console.WriteLine(Value);
                                }
                                else if (s.StartsWith("set "))
                                {
                                    Set(s);
                                    script_var.Ifcount = 1;
                                }
                                else if (s.StartsWith("string "))
                                {
                                    String(s);
                                    script_var.Ifcount = 1;
                                }
                                else if (s == "")
                                {
                                    //empty line 
                                }
                                else if (s == "app.read()")
                                {
                                    Appread();
                                    script_var.Ifcount = 1;
                                }
                                else if (s.StartsWith("#")) { /*ignore #*/ }
                                else
                                {
                                    throw new ArgumentException("Synax error at line '" + line + "'.");
                                }

                                line++;

                                void Int(string input)
                                {
                                    if (input.Contains(" = "))
                                    {
                                        try
                                        {
                                            script_var.Intcount++;
                                            string fullname1 = input.Replace("int ", "");
                                            string fullname2 = fullname1.Replace(" = ", " ");
                                            string[] valuearray = fullname2.Split(" ");
                                            int intvalue = Int16.Parse(valuearray[1]);
                                            string intname = valuearray[0];
                                            switch (script_var.Intcount)
                                            {
                                                case 1:
                                                    script_var.Int1 = intvalue;
                                                    script_var.Intname1 = intname;
                                                    break;
                                                case 2:
                                                    script_var.Int2 = intvalue;
                                                    script_var.Intname2 = intname;
                                                    break;
                                                default:
                                                    string storedcolor = Console.ForegroundColor.ToString();
                                                    Console.ForegroundColor = ConsoleColor.Red;
                                                    Console.WriteLine("int limit reached");
                                                    // set the color after warning to the color before
                                                    Console.ForegroundColor = (ConsoleColor)Enum.Parse(typeof(ConsoleColor), storedcolor);
                                                    break;
                                                    //throw new ArgumentException("Synax error at line '" + line + "'.");
                                                    // max int's reached
                                            }

                                            //new system
                                            Intname = Intname.Append(intname + "=" + intvalue).ToArray();
                                            /*foreach (string lines in Intname) 
                                            {
                                                Console.WriteLine(lines);
                                            }*/
                                        }
                                        catch { throw new ArgumentException("Synax error at line '" + line + "'." + " C8575"); }
                                    }
                                    else
                                    {
                                        throw new ArgumentException("Synax error at line '" + line + "'." + " C3108");
                                    }
                                }
                                void Newif(string input)
                                {
                                    string results = input.Replace("if ", "");
                                    string trimmed = results.Replace(" = ", "/n");
                                    string[] valuearray = trimmed.Split("/n");

                                    bool Locked = false;

                                    if (valuearray[1].StartsWith('"') && valuearray[1].StartsWith('"'))
                                    {
                                        valuearray[1] = valuearray[1].Trim('"');
                                    }

                                    int Num = 0;
                                    int Num2 = 0;

                                    foreach (string lines in Stringname)
                                    {
                                        Num++;
                                        if (!Locked)
                                        {
                                            if (lines == valuearray[0])
                                            {
                                                foreach (string lines2 in Stringvalue)
                                                {
                                                    Num2++;
                                                    if (Num == Num2)
                                                    {
                                                        if (lines2 == valuearray[1])
                                                        {
                                                            Read();
                                                        }
                                                        else if (lines2 != valuearray[1])
                                                        {
                                                            Ignore();
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    void Read()
                                    {
                                        script_var.Ifcount = 2;
                                    }

                                    void Ignore()
                                    {
                                        script_var.Ifcount = 1;
                                    }
                                }
                                void Else()
                                {
                                    if (script_var.Ifcount == 1)
                                    {
                                        script_var.Ifcount = 2;
                                        // inverse ifcount
                                    }
                                    else if (script_var.Ifcount == 2)
                                    {
                                        script_var.Ifcount = 1;
                                        //ignore becouse normal if is executed
                                    }
                                }
                                void Appread()
                                {
                                    Console.Read();
                                }
                                void Appcolor(string input)
                                {
                                    string color = input.Replace("app.color = ", "");
                                    color = char.ToUpper(color[0]) + color.Substring(1);
                                    Console.ForegroundColor = (ConsoleColor)Enum.Parse(typeof(ConsoleColor), color);
                                }
                                void Print(string input)
                                {
                                    string rawdata = input.Replace("print ", "");
                                    if (rawdata.StartsWith('@'))
                                    {
                                        string rawdata2 = rawdata.Remove(0, 1);
                                        Console.Write(Format(rawdata2));
                                    }
                                    else
                                    {
                                        Console.WriteLine(Format(rawdata));
                                    }
                                }
                                void Appsize(string input)
                                {
                                    if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
                                    {
                                        string widthheight = input.Replace("app.size = ", "");
                                        string width;
                                        string height;
                                        widthheight.Replace(" ", "/n");
                                        string[] valuearray = widthheight.Split(' ');
                                        width = valuearray[0];
                                        height = valuearray[1];
                                        int widthint = Int16.Parse(width);
                                        int heightint = Int16.Parse(height);
                                        Console.SetWindowSize(widthint, heightint);
                                    }
                                    else { throw new ArgumentException("Not supported on current platform! Line '" + line + "'." + " C1793"); }
                                }
                                void Appclear()
                                {
                                    Console.Clear();
                                }
                                void Apptitle(string input)
                                {
                                    string rawdata = input.Replace("app.title = ", "");
                                    //Old code.
                                    /*if (rawdata.StartsWith('"') && rawdata.EndsWith('"'))
                                    {
                                        string rawdata2 = rawdata.Trim('"');
                                        Console.Title = rawdata2;
                                    }
                                    else
                                    {
                                        int num = 0;
                                        int num2 = 0;
                                        foreach (string lines in Stringname)
                                        {
                                            num++;
                                            if (lines == rawdata)
                                            {
                                                foreach (string lines2 in Stringvalue)
                                                {
                                                    num2++;
                                                    //Console.WriteLine("num=" + num + " num2=" + num2);
                                                    if (num == num2) { Console.Title = lines2; }
                                                }
                                            }
                                        }
                                    }*/
                                    Console.Title = Format(rawdata);
                                }
                                void Wait(string input)
                                {
                                    string time = input.Replace("wait ", "");
                                    int timeint = Int16.Parse(time);
                                    Thread.Sleep(TimeSpan.FromSeconds(timeint));
                                }
                                string Format(string value)
                                {
                                    string finalvalue = "";
                                    if (value.StartsWith('"') && value.EndsWith('"'))
                                    {
                                        string rawdata2 = value.Trim('"');
                                        finalvalue = rawdata2;
                                    }
                                    else
                                    {
                                        int num = 0;
                                        int num2 = 0;
                                        foreach (string lines in Stringname)
                                        {
                                            num++;
                                            if (lines == value)
                                            {
                                                foreach (string lines2 in Stringvalue)
                                                {
                                                    num2++;
                                                    if (num == num2) { finalvalue = lines2; /*checkreplace();*/ }
                                                }
                                            }
                                        }
                                    }

                                    if (finalvalue.Contains("{environment.username}"))
                                    {
                                        string replace = finalvalue.Replace("{environment.username}", Environment.UserName.ToString());
                                        finalvalue = replace;
                                    }

                                    if (finalvalue.Contains("{environment.machinename}"))
                                    {
                                        string replace = finalvalue.Replace("{environment.machinename}", Environment.MachineName.ToString());
                                        finalvalue = replace;
                                    }

                                    if (finalvalue.Contains("{random.letter}"))
                                    {
                                        char[] chars = "abcdefghijklmnopqrstuvwxyz".ToCharArray();
                                        Random r = new Random();
                                        int i = r.Next(chars.Length);
                                        string replace = finalvalue.Replace("{random.letter}", chars[i].ToString());
                                        finalvalue = replace;
                                    }

                                    if (finalvalue.Contains("{random.number}"))
                                    {
                                        Random r = new Random();
                                        string replace = finalvalue.Replace("{random.number}", r.Next(1, 10).ToString());
                                        finalvalue = replace;
                                    }

                                    if (finalvalue.Contains("<"))
                                    {

                                        int pFrom = finalvalue.IndexOf("<") + "<".Length;
                                        int pTo = finalvalue.LastIndexOf(">");
                                        String result = finalvalue.Substring(pFrom, pTo - pFrom);
                                        result.Replace("<", "");
                                        result.Replace(">", "");
                                        string replace = finalvalue.Replace("<" + result + ">", Format(result));
                                        finalvalue = replace;
                                    }

                                    if (finalvalue.Contains("{Net.IP}"))
                                    {
                                        if (Packages.Net)
                                        {
                                            string GetLocalIPAddress()
                                            {
                                                var host = Dns.GetHostEntry(Dns.GetHostName());
                                                foreach (var ip in host.AddressList)
                                                {
                                                    if (ip.AddressFamily == AddressFamily.InterNetwork)
                                                    {
                                                        return ip.ToString();
                                                    }
                                                }
                                                throw new Exception("No network adapters with an IPv4 address in the system.");
                                            }

                                            string replace = finalvalue.Replace("{Net.IP}", GetLocalIPAddress().ToString());
                                            finalvalue = replace;
                                        }
                                    }

                                    return finalvalue;

                                }
                                void Set(string input)
                                {
                                    string input2 = input.Replace("set ", "");
                                    string[] valuearray = input2.Split(" = ");
                                    int num = 0;
                                    int num2 = 0;
                                    string finalvalue = "";
                                    string value = valuearray[0];
                                    foreach (string lines in Stringname.ToList())
                                    {
                                        num++;
                                        if (lines == valuearray[0])
                                        {
                                            foreach (string lines2 in Stringvalue.ToList())
                                            {
                                                num2++;
                                                if (num == num2)
                                                {
                                                    finalvalue = lines2;
                                                    Stringname.Remove(value);
                                                    Stringvalue.Remove(finalvalue);
                                                    Stringname.Add(value);
                                                    Stringvalue.Add(Format(valuearray[1]));
                                                }
                                            }
                                        }
                                    }
                                }
                                void String(string input)
                                {
                                    try
                                    {
                                        string fullname1 = input.Replace("string ", "");
                                        string fullname2 = fullname1.Replace(" = ", "/n");
                                        string[] valuearray = fullname2.Split("/n");
                                        if (valuearray[1] == "app.read()")
                                        {
                                            string result = Console.ReadLine().ToLower();
                                            Stringname.Add(valuearray[0]);
                                            Stringvalue.Add(result);
                                        }
                                        else if (valuearray[1].StartsWith("dialog.yesno(") && valuearray[1].EndsWith(")"))
                                        {
                                            string result = "True";
                                            if (!AnsiConsole.Confirm(Format(valuearray[1].Replace("dialog.yesno(", "").Replace(")", ""))))
                                            {
                                                result = "False";
                                            }
                                            Stringname.Add(valuearray[0]);
                                            Stringvalue.Add(result);
                                        }
                                        else if (valuearray[1].StartsWith("dialog.numerical(") && valuearray[1].EndsWith(")"))
                                        {
                                            int intresult = AnsiConsole.Ask<int>(Format(valuearray[1].Replace("dialog.numerical(", "").Replace(")", "")));
                                            Stringname.Add(valuearray[0]);
                                            Stringvalue.Add(intresult.ToString());
                                        }
                                        else if (valuearray[1].StartsWith("dialog.color(") && valuearray[1].EndsWith(")"))
                                        {
                                            var result = AnsiConsole.Prompt(
                                            new TextPrompt<string>(Format(valuearray[1].Replace("dialog.color(", "").Replace(")", "")))
                                                .InvalidChoiceMessage("[red]That's not a valid color.[/]")
                                                .AddChoice("red")
                                                .AddChoice("orange")
                                                .AddChoice("yellow")
                                                .AddChoice("chartreuse green")
                                                .AddChoice("green")
                                                .AddChoice("spring green")
                                                .AddChoice("cyan")
                                                .AddChoice("azure")
                                                .AddChoice("blue")
                                                .AddChoice("violet")
                                                .AddChoice("magenta")
                                                .AddChoice("rose"));
                                            Stringname.Add(valuearray[0]);
                                            Stringvalue.Add(result);
                                        }
                                        else if (valuearray[1].StartsWith("dialog.secret(") && valuearray[1].EndsWith(")"))
                                        {
                                            var result = AnsiConsole.Prompt(
                                            new TextPrompt<string>(Format(valuearray[1].Replace("dialog.secret(", "").Replace(")", ""))).Secret());
                                            Stringname.Add(valuearray[0]);
                                            Stringvalue.Add(result);
                                        }
                                        else
                                        {
                                            Stringname.Add(valuearray[0]);
                                            Stringvalue.Add(Format(valuearray[1]));
                                        }
                                    }
                                    catch { Console.WriteLine("error"); }
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            if (e.Source != null)
                                Console.ForegroundColor = ConsoleColor.Red;
                            Console.WriteLine("Exception: {0}" + " at line " + line, e);
                            Thread.Sleep(10000);
                            throw;
                        }
                    }
                }
            }
            void Debuger()
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("===============");
                Console.WriteLine("  Kookaburra Debuger - Sysinfo: is64x=" + check_environment.Is64x + " OSversion=" + check_environment.OSversion + " ProcessorCount=" + Environment.ProcessorCount + " CurrentManagedThreadId=" + Environment.CurrentManagedThreadId);
                Console.WriteLine("  Type 'app.debug-off' in the first line of your program to disable this message.");
                Console.WriteLine("===============");
                // default color
                Console.ForegroundColor = ConsoleColor.White;
            }
        }
    }
}