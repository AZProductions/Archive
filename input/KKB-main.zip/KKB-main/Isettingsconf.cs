﻿namespace KKB
{
    class Isettingsconf
    {
        public static string Currentdir { get; set; }
        // true = file false = dir
        public static bool Filedir { get; set; }
        public static bool Networkkey { get; set; }
        public static bool Quietmode { get; set; }
        public static string Envloc { get; set; }
        public static int SavedHeight { get; set; }
        public static int SavedWidth { get; set; }
        public static bool ShowRainbow { get; set; }
        public static bool FR { get; set; }
    }
}
