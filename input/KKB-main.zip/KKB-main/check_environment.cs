﻿namespace KKB
{
    class check_environment
    {
        public static bool Is64x { get; set; }
        public static string Username { get; set; }
        public static string OSversion { get; set; }
        public static bool Debugoff { get; set; }
    }
}
