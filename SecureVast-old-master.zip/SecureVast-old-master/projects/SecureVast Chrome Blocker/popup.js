// popup.js

function runSwitchjs() {
  chrome.tabs.executeScript({
    file: 'switch.js'
  });
}

document.getElementById('clickme').addEventListener('click', runSwitchjs);
// switch.js

for (var i = 0; document.images.length; i++) {
  // Change the url to anyting you want!
  document.images[i].src = "https://avatars0.githubusercontent.com/u/66299945?s=400&u=4e61ecee48da81fd4e6ce4d897af96e794a1806d&v=4.png"
};

  chrome.webNavigation.onCompleted.addListener(function() {
      alert("This is my favorite website!");
  }, {url: [{urlMatches : 'https://www.google.com/'}]});