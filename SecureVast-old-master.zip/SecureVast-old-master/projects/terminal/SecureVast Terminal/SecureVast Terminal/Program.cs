﻿using System;
using System.CodeDom.Compiler;
using System.IO;
using System.Runtime.InteropServices;
using System.Threading;

namespace SecureVast_Terminal
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "SecureVast Terminal";
            bool isrunning = true;
            Console.WriteLine("SecureVast Terminal [Version 1.0]");

            while (isrunning)
            {
                bool validcommandfound = false;
                Console.Write("SecureVast>");
                string input = Console.ReadLine().ToLower();

                if (input == "help")
                {
                    validcommandfound = true;
                    Console.WriteLine("");
                    Console.WriteLine("help - shows help page");
                    Console.WriteLine("clear - clears the screen");
                    Console.WriteLine("restart - restarts the terminal");
                    Console.WriteLine("exit - exits the terminal");
                    Console.WriteLine("devmode [parameter] - activates devmode");
                    Console.WriteLine("");
                }

                if (input == "clear")
                {
                    validcommandfound = true;
                    Console.Clear();
                }

                if (input == "tempf")
                {
                    validcommandfound = true;
                    Console.WriteLine("Usage: tempf [type] [data]");
                    Console.WriteLine("");
                }
                
                if (input == "exit")
                {
                    validcommandfound = true;
                    Environment.Exit(0);
                }

                if (input == "devmode")
                {
                    validcommandfound = true;
                    Console.WriteLine("The syntax of the command is incorrect.");
                    Console.WriteLine("");
                    Console.WriteLine("Example: devmode 2");
                    Console.WriteLine("0 - Full Developer Control");
                    Console.WriteLine("1 - Experimental Access");
                    Console.WriteLine("2 - Full Developer Control + Experimental Access");
                    Console.WriteLine("");
                }

                if (input == "devmode 0")
                {
                    validcommandfound = true;
                    Console.Clear();
                    Console.WriteLine("Starting [-----]");
                    Thread.Sleep(500);
                    Console.Clear();
                    Console.WriteLine("Starting [#----]");
                    Thread.Sleep(500);
                    Console.Clear();
                    Console.WriteLine("Starting [##---]");
                    Thread.Sleep(500);
                    Console.Clear();
                    Console.WriteLine("Starting [###--]");
                    Thread.Sleep(500);
                    Console.Clear();
                    Console.WriteLine("Starting [####-]");
                    Thread.Sleep(500);
                    Console.Clear();
                    Console.WriteLine("Starting [#####]");
                    Thread.Sleep(1000);
                    Console.Clear();
                    Console.WriteLine("");
                    Console.WriteLine("");
                    Console.WriteLine("                                      ,%@&,                              ---------- ");
                    Console.WriteLine("                                     /@@@@@(                            | Ver. 1.0 |");
                    Console.WriteLine("                                    @@@@@@@@@.                          | AZ 2020  |");
                    Console.WriteLine("                                  /@@@@@@@@@@@/                         |          |");
                    Console.WriteLine("                                 %@@@@@@@@@@@@@&                        | Loading  |");
                    Console.WriteLine("                               *@@@@@@@@@@@@@@@@@/                       ---------- ");
                    Console.WriteLine("                              #@@@@@@@@@@@@@@@@@@@%.                            ");
                    Console.WriteLine("                            ,@@@%...................                            ");
                    Console.WriteLine("                           #@@@@(                                               ");
                    Console.WriteLine("                         ,&@@@@@(                                               ");
                    Console.WriteLine("                        #@@@@@@@(                                               ");
                    Console.WriteLine("                      ,&@@@@@@@@@@@@@@@@@@@@@@*                                 ");
                    Console.WriteLine("                     /@@@@@@@@@@@@@@@@@@@@@@&          (@@@(                    ");
                    Console.WriteLine("                   .@@@@@@@@@@@@@@@@@@@@@@@*         .&@@@@@@,                  ");
                    Console.WriteLine("                  /@@@@@@@@@@@@@@@@@@@@@@%.         /@@@@@@@@@(                 ");
                    Console.WriteLine("                 %@@@@@@@@@@@@@@@@@@@@@@/         .%@@@@@@@@@@@&.               ");
                    Console.WriteLine("               /@@@@@@@@@@@@@@@@@@@@@@%.                   %@@@@@(              ");
                    Console.WriteLine("              #@@@@@@@@@@@@@@@@@@@@@@(                     %@@@@@@%.            ");
                    Console.WriteLine("               .,,,,,,,,,,,,,,,,,,,.                       .,,,,,.              ");
                    Console.WriteLine("");
                    Thread.Sleep(5000);
                    Console.Clear();
                }

                if (input == "devmode 1")
                {
                    validcommandfound = true;
                    Console.WriteLine("test");
                }

                if (input == "devmode 2")
                {
                    validcommandfound = true;
                    Console.WriteLine("test");
                }

                if (!validcommandfound)
                {
                    if (input == "")
                    { }
                    else
                    {
                        Console.WriteLine("");
                        Console.WriteLine("Command '{0}' not found.", input);
                        Console.WriteLine("");
                    }
                }
            }
        }
    }
}
