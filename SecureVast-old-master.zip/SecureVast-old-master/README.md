 ![SecureVast Logo](https://imgur.com/pd1hlFF.png)
 ![version](https://img.shields.io/badge/Version-200828.11-green)
 ![websiteup?](https://img.shields.io/website?down_color=red&down_message=offline&up_color=green&up_message=online&url=http%3A%2F%2FSecureVast.ml)
 ![size](https://img.shields.io/github/repo-size/AZProductions/SecureVast)
# SecureVast Antivirus
###### *This Repository contains the SecureVast Extension SDK and the SecureVast Source Code* 

#### Why SecureVast?

* Free and Easy To Use
* We don't collect Data!
* SecureVast only Runs if you click on it
___






## Installation 


###### Requirements
* Windows 10
     - Mac-os and Linux not supported
* .net FrameWork Version 4.7.2
     - This is included in the installer

###### How do you install it?
1. Go to SecureVast.ml and download the latest version
2. Run the installer
3. Done

<a href="http://www.youtube.com/watch?feature=player_embedded&v=cBN--BXtMCQ
" target="_blank"><img src="http://img.youtube.com/vi/cBN--BXtMCQ/0.jpg" 
alt="YT TUTORIAL - AZ PRODUCTIONS" width="240" height="180" border="10" /></a>






___
## Extensions SDK

##### Requirements

* Windows 10
* Visual Studio (personal, professional or community)
     - Version 2019 or later
* Winforms
     - Winforms 2
      - Frameworks like MetroUi not allowed
     - .net Framework Version 4.7.2


###### How to Create and upload your extension to the Store

1. Download the template [here](https://github.com/AZProductions/SecureVast/tree/extension)
     - Clone the Github branch
2. Open the file in **Visual Studio 2019**
3. Make Changes to the file
4. Upload it to a **New Github Repository**
5. Fill the details in the [Submitting Form](https://developers.securevast.ml/extentions-submit)
6. Wait for the email that accepts or rejects the extension
7. Wait a few weeks and your extension is in the store

###### How to activate your Devellopers Account?
1. Open: SecureVast Terminal 
2. Type:
``` "devmode [0, 1, 2]" ```

***

### SecureVast Terminal Commands


###### How to Create a ***tempf*** file
Type ``` "tempf create [type]" ```

***
## Videos
<a href="http://www.youtube.com/watch?feature=player_embedded&v=cBN--BXtMCQ
" target="_blank"><img src="http://img.youtube.com/vi/cBN--BXtMCQ/0.jpg" 
alt="YT TUTORIAL - AZ PRODUCTIONS" width="240" height="180" border="10" /></a>
<a href="http://www.youtube.com/watch?feature=player_embedded&v=6rb-qqpLYoA
" target="_blank"><img src="http://img.youtube.com/vi/6rb-qqpLYoA/0.jpg" 
alt="YT TUTORIAL - AZ PRODUCTIONS" width="240" height="180" border="10" /></a>



***
###### ***SecureVast.ml [AZ PRODUCTIONS 2020 | SecureVast]***
