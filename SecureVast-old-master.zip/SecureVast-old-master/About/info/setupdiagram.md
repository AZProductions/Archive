
##### Setup Diagram
![Setup Diagram](https://imgur.com/VhGXlpt.png)
